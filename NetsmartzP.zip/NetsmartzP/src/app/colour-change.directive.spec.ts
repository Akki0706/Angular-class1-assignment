import { ColourChangeDirective } from './colour-change.directive';

describe('ColourChangeDirective', () => {
  it('should create an instance', () => {
    const directive = new ColourChangeDirective();
    expect(directive).toBeTruthy();
  });
});
