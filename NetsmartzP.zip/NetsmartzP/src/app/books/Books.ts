//First of all we have to give the interface to our elements//
export interface Books{
    name: string;
    id:number;
    title:string;
    author:string;
    availabilitystatus:boolean;
    summary:string;
    numberofPages:number;
    publicationDate:string;
}