//Import the interface here and make the array in the form of lists to reflect the details//
import { Books } from "./books/Books";
export const BOOKS: Books[] = [
    {name:"Maths" , id:1, title:'Book1', author:'Author1',summary:'Summary1',numberofPages:200, publicationDate:'1/2/2020',availabilitystatus:true},
    {name:"Physics" , id:2, title:'Book1', author:'Author1',summary:'Summary1',numberofPages:200, publicationDate:'1/2/2020',availabilitystatus:true},
    {name:"Chemistry" , id:3, title:'Book1', author:'Author1',summary:'Summary1',numberofPages:200, publicationDate:'1/2/2020',availabilitystatus:true},
    {name:"DSA" , id:4, title:'Book1', author:'Author1',summary:'Summary1',numberofPages:200, publicationDate:'1/2/2020',availabilitystatus:true},
    {name:"Computer Network" , id:5, title:'Book1', author:'Author1',summary:'Summary1',numberofPages:200, publicationDate:'1/2/2020',availabilitystatus:true},
   ];